using PTManagementSystem.Domain.Enums;

namespace PTManagementSystem.Presentation.DTOs
{
    public class UserDTO
    {
        public Guid Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public bool IsEmailConfirmed { get; set; }
        public UserType UserType { get; set; }
        public UserProfileDTO Profile { get; set; }
        public PaymentInfoDTO PaymentInfo { get; set; }
        public TrainerProfileDTO TrainerProfile { get; set; }
    }
}