using System.ComponentModel.DataAnnotations;

namespace PTManagementSystem.Presentation.DTOs
{
    public class RegisterUserDTO
    {
        [Required]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [MinLength(8)]
        public string Password { get; set; }

        [Required]
        public UserType UserType { get; set; }

        public UserProfileDTO Profile { get; set; }
        public PaymentInfoDTO PaymentInfo { get; set; }
        public TrainerProfileDTO TrainerProfile { get; set; }
    }
}