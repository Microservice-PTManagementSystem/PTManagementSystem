namespace PTManagementSystem.Presentation.DTOs
{
    public class TrainerProfileDTO
    {
        public string Specialization { get; set; }
        public string Certifications { get; set; }
        public string Experience { get; set; }
        public decimal HourlyRate { get; set; }
        public string Biography { get; set; }
        public List<string> AvailableTimeSlots { get; set; }
    }
}