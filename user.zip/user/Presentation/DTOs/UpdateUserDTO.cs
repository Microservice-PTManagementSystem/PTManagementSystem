namespace PTManagementSystem.Presentation.DTOs
{
    public class UpdateUserDTO
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public UserProfileDTO Profile { get; set; }
        public PaymentInfoDTO PaymentInfo { get; set; }
        public TrainerProfileDTO TrainerProfile { get; set; }
    }
}